<?php
$_SESSION["girisKontrol"] = 0;
session_start();

session_destroy();
header("Location: index.php");

?>