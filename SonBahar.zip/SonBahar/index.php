<?php
ob_start();
$user = '12345';
$pass = '1416';
if(isset($_POST['username'])){
	$username = $_POST['username'];
	$password = $_POST['password'];

	if($username == $user && $password == $pass){
		echo "Öğrenci Tanımlandı";
		header('location:islem.php');
	}
	else {
		echo 'Hatalı Öğrenci Bilgisi';
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SonBahar</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
      
<div class="login">
	<div>

	</div class="login-screen">
	<div class="app-title">
		<h1>Giriş Yap</h1>
	<form action="" method="post">
	</div>
    <div class="login-form">
		<div class="control-group">
			<input type="text" name="username" class="login-field" placeholder="Kullanıcı Adı" id="login-name">
			<label class="login-field-icon fui-user" for="login-name"></label>
		</div>
        <div class="control-group">
			<input type="password" name="password" class="login-field" placeholder="şifre" id="login-pass">
			<label class="login-field-icon fui-user" for="login-pass"></label>
		</div>
		<button href="index.php" class="btn btn-primary btn-large btn-block">Giriş Yapiniz</button>
	</div>
	</form>
</div>
</body>
</html>