<?php
echo "Başarı ile giriş yaptın: 'Bahar Öner'";

?>
<br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="main.scss">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SonBahar</title>
</head>
<body>
<form action="" method="post">
1.Ekonomi / Kredi:3
    <input type="number" name="vize1" placeholder="Vize" min="0" max="100" required>
    <input type="number" name="final1" placeholder="Final" min="0" max="100" required>

    <?php
        if(isset($_POST["submit"])){
            $vize1=@$_POST["vize1"];
            $final1=@$_POST["final1"];

            $vizeyüzde1=$vize1*0.40;
            $finalyüzde1=$final1*0.60;
            $toplam1=$vizeyüzde1+$finalyüzde1;

            echo "Puanınız : ";
            echo round($toplam1);

            if($toplam1<=100 && $toplam1>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam1<=89 && $toplam1>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam1<=84 && $toplam1>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam1<=79 && $toplam1>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam1<=74 && $toplam1>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam1<=69 && $toplam1>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam1<=64 && $toplam1>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam1<=59 && $toplam1>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam1<=49 && $toplam1>=0){
                echo " - FF ile kaldınız.";
            }
        }
        

	?>

<br><br>
2.HUKUK / Kredi:2
    <input type="number" name="vize2" placeholder="Vize" min="0" max="100" required>
    <input type="number" name="final2" placeholder="Final" min="0" max="100" required>
    <?php
        if(isset($_POST["submit"])){
            $vize2=@$_POST["vize2"];
            $final2=@$_POST["final2"];

            $vizeyüzde2=$vize2*0.40;
            $finalyüzde2=$final2*0.60;
            $toplam2=$vizeyüzde2+$finalyüzde2;

            echo "Puanınız : ";
            echo round($toplam2);

            if($toplam2<=100 && $toplam2>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam2<=89 && $toplam2>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam2<=84 && $toplam2>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam2<=79 && $toplam2>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam2<=74 && $toplam2>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam2<=69 && $toplam2>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam2<=64 && $toplam2>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam2<=59 && $toplam2>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam2<=49 && $toplam2>=0){
                echo " - FF ile kaldınız.";
            }
        }

	?>

<br><br>
3.İKTİSAT / Kredi:3
    <input type="number" name="vize3" placeholder="Vize" min="0" max="100" required>
    <input type="number" name="final3" placeholder="Final" min="0" max="100" required>
    <?php
        if(isset($_POST["submit"])){
            $vize3=@$_POST["vize3"];
            $final3=@$_POST["final3"];

            $vizeyüzde3=$vize3*0.40;
            $finalyüzde3=$final3*0.60;
            $toplam3=$vizeyüzde3+$finalyüzde3;

            echo "Puanınız : ";
            echo round($toplam3);

            if($toplam3<=100 && $toplam3>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam3<=89 && $toplam3>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam3<=84 && $toplam3>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam3<=79 && $toplam3>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam3<=74 && $toplam3>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam3<=69 && $toplam3>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam3<=64 && $toplam3>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam3<=59 && $toplam3>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam3<=49 && $toplam3>=0){
                echo " - FF ile kaldınız.";
            }
        }

    ?>

<br><br>
4.Pazarlama / Kredi:3
    <input type="number" name="vize4" placeholder="Vize" min="0" max="100" required>
    <input type="number" name="final4" placeholder="Final" min="0" max="100" required>
    <?php
        if(isset($_POST["submit"])){
            $vize4=@$_POST["vize4"];
            $final4=@$_POST["final4"];

            $vizeyüzde4=$vize4*0.40;
            $finalyüzde4=$final4*0.60;
            $toplam4=$vizeyüzde4+$finalyüzde4;

            echo "Puanınız : ";
            echo round($toplam4);

            if($toplam4<=100 && $toplam4>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam4<=89 && $toplam4>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam4<=84 && $toplam4>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam4<=79 && $toplam4>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam4<=74 && $toplam4>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam4<=69 && $toplam4>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam4<=64 && $toplam4>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam4<=59 && $toplam4>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam4<=49 && $toplam4>=0){
                echo " - FF ile kaldınız.";
            }
        }

    ?>

<br><br>
5.İstatislik / Kredi:3
    <input type="number" name="vize5" placeholder="Vize" min="0" max="100" required> 
    <input type="number" name="final5" placeholder="Final" min="0" max="100" required>
    <?php
        if(isset($_POST["submit"])){
            $vize5=@$_POST["vize5"];
            $final5=@$_POST["final5"];

            $vizeyüzde5=$vize5*0.40;
            $finalyüzde5=$final5*0.60;
            $toplam5=$vizeyüzde5+$finalyüzde5;

            echo "Puanınız : ";
            echo round($toplam5);

            if($toplam5<=100 && $toplam5>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam5<=89 && $toplam5>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam5<=84 && $toplam5>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam5<=79 && $toplam5>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam5<=74 && $toplam5>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam5<=69 && $toplam5>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam5<=64 && $toplam5>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam5<=59 && $toplam5>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam5<=49 && $toplam5>=0){
                echo " - FF ile kaldınız.";
            }
        }

    ?>

<br><br>
6.İngilizce / Kredi:3
    <input type="number" name="vize6" placeholder="Vize" min="0" max="100" required>
    <input type="number" name="final6" placeholder="Final" min="0" max="100" required>

    <?php
        if(isset($_POST["submit"])){
            $vize6=@$_POST["vize6"];
            $final6=@$_POST["final6"];

            $vizeyüzde6=$vize6*0.40;
            $finalyüzde6=$final6*0.60;
            $toplam6=$vizeyüzde6+$finalyüzde6;

            echo "Puanınız : ";
            echo round($toplam6);

            if($toplam6<=100 && $toplam6>=90){
                echo " - AA ile geçtiniz.";
            }
            if($toplam6<=89 && $toplam6>=85){
                echo " - BA ile geçtiniz.";
            }
            if($toplam6<=84 && $toplam6>=80){
                echo " - BB ile geçtiniz.";
            }
            if($toplam6<=79 && $toplam6>=75){
                echo " - CB ile geçtiniz.";
            }
            if($toplam6<=74 && $toplam6>=70){
                echo " - CC ile geçtiniz.";
            }
            if($toplam6<=69 && $toplam6>=65){
                echo " - DC ile geçtiniz.";
            }
            if($toplam6<=64 && $toplam6>=60){
                echo " - DD ile geçtiniz.";
            }
            if($toplam6<=59 && $toplam6>=50){
                echo " - FD ile geçtiniz.";
            }
            if($toplam6<=49 && $toplam6>=0){
                echo " - FF ile kaldınız.";
            }
        }

    ?>

<br><br>

    <?php
        if(isset($_POST["submit"])){
            $toplam=$toplam1+$toplam2+$toplam3+$toplam4+$toplam5+$toplam6;
            $sonuc=$toplam/6;
            //$sonuc= number_format($sonuc, 2, ',', '.');
            echo "Krediniz : 17 Ortalamanız: ";
            echo round($sonuc);

            if($sonuc<=100 && $sonuc>=90){
                echo " - AA ile geçtiniz.";
            }
            if($sonuc<=89 && $sonuc>=85){
                echo " - BA ile geçtiniz.";
            }
            if($sonuc<=84 && $sonuc>=80){
                echo " - BB ile geçtiniz.";
            }
            if($sonuc<=79 && $sonuc>=75){
                echo " - CB ile geçtiniz.";
            }
            if($sonuc<=74 && $sonuc>=70){
                echo " - CC ile geçtiniz.";
            }
            if($sonuc<=69 && $sonuc>=65){
                echo " - DC ile geçtiniz.";
            }
            if($sonuc<=64 && $sonuc>=60){
                echo " - DD ile geçtiniz.";
            }
            if($sonuc<=59 && $sonuc>=50){
                echo " - FD ile geçtiniz.";
            }
            if($sonuc<=49 && $sonuc>=0){
                echo " - FF ile kaldınız.";
            }
        }
    ?>
    <br><br>
    <input name="submit" type="submit" value="Hesapla" >
    </form>

<br>
<a href="cikis.php">Çıkış Yap</a> <a href="islem.php">Tekrar Dene</a>
</body>
</html>
